<?php
$password = "111111";
$realpassword = "111111";
echo "right</br>";
if($password != $realpassword)
{
	echo "happy";
}
else
{
	echo "sad</br>";
}
#echo $result;
?>